package com.location.reminder.sound.model

data class AddressListModel(
    var placeId: String,
    var placeName: String,
    var placeDescription: String
)
