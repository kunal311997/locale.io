package com.location.reminder.sound.model

data class LocationData(
    var latitude: Double? = null,
    var longitude: Double? = null
)
