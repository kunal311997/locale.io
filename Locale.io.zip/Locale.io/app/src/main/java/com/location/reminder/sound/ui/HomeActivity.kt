package com.location.reminder.sound.ui

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import com.location.reminder.sound.*
import com.location.reminder.sound.util.Constants
import com.location.reminder.sound.util.SharedPrefClient
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity() {

    private lateinit var sharedPrefClient: SharedPrefClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        initSharedPref()
        setDataToUI()
        addOnClickListeners()
    }

    override fun onResume() {
        super.onResume()
        checkSharedPrefData()
    }

    private fun checkSharedPrefData() {
        if (sharedPrefClient.getAddress() == "") {
            groupNoDataPresent.visible()
            clDataPresent.gone()
        } else {
            groupNoDataPresent.gone()
            clDataPresent.visible()
        }
    }

    private fun initSharedPref() {
        sharedPrefClient = SharedPrefClient()
        sharedPrefClient.init(this)
    }

    private fun addOnClickListeners() {
        btnAddReminder.setOnClickListener {
            val intent = Intent(this, AddReminderActivity::class.java)
            resultLauncher.launch(intent)
        }

        imgEdit.setOnClickListener {
            val intent = Intent(this, AddReminderActivity::class.java)
            intent.putExtra(Constants.IS_FROM_EDIT, true)
            resultLauncher.launch(intent)
        }

        imgPlayPause.setOnClickListener {
            if (sharedPrefClient.isServiceRunning()) {
                imgPlayPause.setImageResource(R.drawable.ic_baseline_play_circle_outline_24)
                stopLocationUpdateService()
                showToast("Stopped")
                sharedPrefClient.setServiceRunning(false)
            } else {
                imgPlayPause.setImageResource(R.drawable.ic_baseline_stop_circle_24)
                startLocationUpdateService()
                showToast("Started")
                sharedPrefClient.setServiceRunning(true)
            }
        }

        imgDelete.setOnClickListener {
            sharedPrefClient.clearData()
            groupNoDataPresent.visible()
            clDataPresent.gone()
            stopLocationUpdateService()
            NotificationManagerCompat.from(this).cancelAll()
        }
    }

    private val resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                // There are no request codes
                val data: Intent? = result.data
                groupNoDataPresent.gone()
                clDataPresent.visible()
                setDataToUI()
            }
        }

    private fun setDataToUI() {
        txtSoundMode.text = sharedPrefClient.getSoundMode()
        txtLocationLabel.text = resources.getString(
            R.string.whenever_you_are_within_x_meters_of, sharedPrefClient.getDistance().toString()
        )
        txtLocationUpdationTime.text = resources.getString(
            R.string.location_will_update_every_x_seconds,
            sharedPrefClient.getUpdateTime().toString()
        )
        txtLocation.text = sharedPrefClient.getAddress()
        textCreatedAt.text = sharedPrefClient.getCreatedAt()
    }

}